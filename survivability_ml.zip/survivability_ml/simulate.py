"""
simulate.py  -  Abstract Monte Carlo generator for an aircraft survivability STUDY.

IMPORTANT HONESTY NOTE (put this in your report and say it in the viva)
-----------------------------------------------------------------------
* There is no public dataset of real missile-vs-aircraft outcomes.
* Every number in ASSUMED below is an assumption chosen by us, NOT a measurement of
  any real system. The models therefore learn the behaviour of THIS simulator.
* The protective "hybrid" mode is a generic black box: it detects with probability p
  and neutralises with probability q. No seeker, fuze, warhead, guidance or sizing
  is modelled anywhere in this project.
* Real data enters in ONE place only: real aircraft speeds/altitudes (e.g. from the
  OpenSky Network ADS-B data) can be bootstrapped into the aircraft-kinematics
  columns with  --real-csv  so the aircraft side of the scenarios is realistic.

Usage:
    python simulate.py                       # 6000 scenarios, fully synthetic
    python simulate.py --n 10000 --seed 7
    python simulate.py --real-csv opensky_states.csv
"""
import argparse
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).parent
DATA = ROOT / "data"
MODES = ["none", "decoy", "maneuver", "hybrid"]

# ---- ASSUMED parameters (all fictional, change them and re-run to study sensitivity)
ASSUMED = {
    "decoy_unit_effect": 0.12,      # chance one decoy unit pulls the threat away
    "maneuver_max_effect": 0.65,    # max reduction in hit chance from manoeuvring
    "hybrid_p_detect": 0.75,        # generic: protective unit detects the threat
    "hybrid_p_neutralise": 0.55,    # generic: protective unit neutralises it, given detection
}


def _sigmoid(z):
    return 1.0 / (1.0 + np.exp(-z))


def effective_measures(mode, n):
    """Number of protective units actually used by each mode."""
    return {"none": 0, "maneuver": 1}.get(mode, n)


def survival_probability(df, a=ASSUMED):
    """Abstract survival probability for every row of df (the 'ground truth' of the sim)."""
    td, clutter = df["threat_difficulty"], df["weather_clutter"]
    warn, speed = df["warning_time_s"], df["aircraft_speed_mps"]

    # baseline chance the threat connects: closer, harder, cluttered, little warning => worse
    z = (-0.6 + 2.4 * td + 0.03 * (50 - df["engagement_range_km"]) - 0.05 * warn
         + 0.8 * clutter - 0.004 * (speed - 220) + 0.03 * (df["altitude_km"] - 6))
    p_base = _sigmoid(z)

    n = df["n_measures"]
    decoy_eff = 1 - (1 - a["decoy_unit_effect"] * (1 - 0.5 * td) * (1 - 0.4 * clutter)) ** n
    man_eff = (a["maneuver_max_effect"] * (1 - np.exp(-warn / 12)) * (1 - 0.5 * td)
               * np.clip(speed / 250, 0.6, 1.2))
    neutral = (a["hybrid_p_detect"] * a["hybrid_p_neutralise"] * (1 - 0.5 * clutter)
               * (1 - np.exp(-warn / 8)))

    p_hit = np.select(
        [df["protection_mode"] == "none", df["protection_mode"] == "decoy",
         df["protection_mode"] == "maneuver"],
        [p_base, p_base * (1 - decoy_eff), p_base * (1 - man_eff)],
        default=(1 - neutral) * p_base * (1 - decoy_eff) * (1 - 0.8 * man_eff),
    )
    return np.clip(1 - p_hit, 0, 1)


def normalise_flight_csv(raw, speed_unit="m/s", alt_unit="m"):
    """Turn an OpenSky-style CSV into columns lat, lon, speed_mps, altitude_km."""
    df = raw.copy()
    df.columns = [str(c).strip().lower() for c in df.columns]

    def pick(cands):
        return next((c for c in cands if c in df.columns), None)

    lat, lon = pick(["lat", "latitude"]), pick(["lon", "longitude", "lng"])
    spd = pick(["velocity", "groundspeed", "ground_speed", "speed", "gs"])
    alt = pick(["baroaltitude", "baro_altitude", "geoaltitude", "geo_altitude", "altitude", "alt"])
    if spd is None or alt is None:
        raise ValueError("Need a speed column (velocity/groundspeed/speed) and an "
                         "altitude column (baroaltitude/geoaltitude/altitude).")
    out = pd.DataFrame({
        "lat": pd.to_numeric(df[lat], errors="coerce") if lat else np.nan,
        "lon": pd.to_numeric(df[lon], errors="coerce") if lon else np.nan,
        "speed_mps": pd.to_numeric(df[spd], errors="coerce"),
        "altitude_km": pd.to_numeric(df[alt], errors="coerce"),
    })
    out["speed_mps"] *= {"m/s": 1.0, "knots": 0.514444, "km/h": 1 / 3.6}[speed_unit]
    out["altitude_km"] *= {"m": 1e-3, "ft": 3.048e-4, "km": 1.0}[alt_unit]
    out = out.dropna(subset=["speed_mps", "altitude_km"])
    return out[out.speed_mps.between(80, 350) & out.altitude_km.between(0.3, 13)].reset_index(drop=True)


def generate(n=6000, seed=42, kinematics=None, dirty=True):
    """Generate n scenarios (plus realistic 'dirt' to clean, if dirty=True)."""
    rng = np.random.default_rng(seed)
    df = pd.DataFrame({
        "engagement_range_km": rng.uniform(5, 80, n).round(2),
        "warning_time_s": rng.uniform(2, 40, n).round(2),
        "threat_difficulty": rng.uniform(0, 1, n).round(3),
        "weather_clutter": rng.uniform(0, 1, n).round(3),
        "protection_mode": rng.choice(MODES, n),
    })
    if kinematics is not None and len(kinematics) > 0:   # REAL aircraft kinematics
        idx = rng.integers(0, len(kinematics), n)
        df["aircraft_speed_mps"] = kinematics["speed_mps"].to_numpy()[idx].round(1)
        df["altitude_km"] = kinematics["altitude_km"].to_numpy()[idx].round(3)
    else:
        df["aircraft_speed_mps"] = rng.uniform(150, 300, n).round(1)
        df["altitude_km"] = rng.uniform(1, 12, n).round(2)

    n_units = rng.integers(1, 7, n)
    df["n_measures"] = [effective_measures(m, k) for m, k in zip(df.protection_mode, n_units)]

    df["true_survival_prob"] = survival_probability(df)          # leakage column (dropped later)
    df["survived"] = (rng.random(n) < df["true_survival_prob"]).astype(int)
    df.insert(0, "scenario_id", np.arange(1, n + 1))

    if dirty:   # make the cleaning step meaningful (rubric: data cleaning)
        for col in ["warning_time_s", "weather_clutter", "altitude_km", "aircraft_speed_mps"]:
            df.loc[rng.random(n) < 0.025, col] = np.nan
        df.loc[rng.random(n) < 0.006, "aircraft_speed_mps"] *= 10      # sensor glitches
        df.loc[rng.random(n) < 0.004, "engagement_range_km"] *= -1     # impossible values
        dups = df.sample(frac=0.01, random_state=seed)
        df = pd.concat([df, dups], ignore_index=True).sample(frac=1, random_state=seed)
    return df.reset_index(drop=True)


def run(n=6000, seed=42, real_csv=None, speed_unit="m/s", alt_unit="m"):
    DATA.mkdir(exist_ok=True)
    kin = None
    if real_csv:
        kin = normalise_flight_csv(pd.read_csv(real_csv), speed_unit, alt_unit)
        print(f"Using {len(kin)} real aircraft kinematic rows from {real_csv}")
        kin.to_csv(DATA / "real_kinematics_used.csv", index=False)
    df = generate(n, seed, kin)
    df.to_csv(DATA / "raw_simulated.csv", index=False)
    print(f"Saved {len(df)} raw rows -> {DATA / 'raw_simulated.csv'}")
    return df


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=6000)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--real-csv", default=None)
    ap.add_argument("--speed-unit", default="m/s", choices=["m/s", "knots", "km/h"])
    ap.add_argument("--alt-unit", default="m", choices=["m", "ft", "km"])
    a = ap.parse_args()
    run(a.n, a.seed, a.real_csv, a.speed_unit, a.alt_unit)
