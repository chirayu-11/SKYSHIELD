"""
data_prep.py - cleaning rules (rubric item 1: Data Cleaning & Splitting).

Order matters for avoiding data leakage:
  1. Row-level cleaning that needs no statistics (duplicates, impossible values -> NaN,
     drop identifier + leakage columns) is done BEFORE the split.
  2. Anything that learns from data (median imputation, scaling, one-hot) lives inside the
     sklearn Pipeline, so it is fitted on the TRAIN split only.
"""
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

NUM_FEATURES = ["engagement_range_km", "aircraft_speed_mps", "altitude_km", "warning_time_s",
                "threat_difficulty", "weather_clutter", "n_measures"]
CAT_FEATURES = ["protection_mode"]
ALL_FEATURES = NUM_FEATURES + CAT_FEATURES
TARGET = "survived"                      # 1 = aircraft survived, 0 = hit
LEAKAGE_COLUMNS = ["true_survival_prob"]  # the simulator's own probability: NEVER a feature
ID_COLUMNS = ["scenario_id"]

VALID_RANGES = {
    "engagement_range_km": (1, 150),
    "aircraft_speed_mps": (50, 400),
    "altitude_km": (0.1, 20),
    "warning_time_s": (0, 120),
    "threat_difficulty": (0, 1),
    "weather_clutter": (0, 1),
}


def clean(raw):
    """Return (clean_df, report_dict)."""
    df = raw.copy()
    report = {"rows_raw": int(len(df)),
              "missing_before": {k: int(v) for k, v in df.isna().sum().items() if v > 0}}

    before = len(df)
    df = df.drop_duplicates()
    report["duplicates_removed"] = int(before - len(df))

    invalid = {}
    for col, (lo, hi) in VALID_RANGES.items():
        bad = df[col].notna() & ~df[col].between(lo, hi)
        invalid[col] = int(bad.sum())
        df.loc[bad, col] = np.nan                      # imputed later, inside the pipeline
    report["invalid_values_set_to_nan"] = {k: v for k, v in invalid.items() if v}

    df = df.drop(columns=[c for c in LEAKAGE_COLUMNS + ID_COLUMNS if c in df.columns])
    report["dropped_columns"] = LEAKAGE_COLUMNS + ID_COLUMNS

    df = df.dropna(subset=[TARGET])
    df[TARGET] = df[TARGET].astype(int)
    report["rows_clean"] = int(len(df))
    report["missing_after_cleaning_before_imputation"] = {
        k: int(v) for k, v in df.isna().sum().items() if v > 0}
    report["class_balance_survived"] = round(float(df[TARGET].mean()), 4)
    return df.reset_index(drop=True), report


def make_preprocessor():
    num = Pipeline([("impute", SimpleImputer(strategy="median")), ("scale", StandardScaler())])
    cat = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
    return ColumnTransformer([("num", num, NUM_FEATURES), ("cat", cat, CAT_FEATURES)])
