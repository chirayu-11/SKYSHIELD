"""
app.py - Streamlit interface (rubric item 3).   Run:  streamlit run app.py

Pages: Overview | Data & Cleaning | Model Comparison | Understand a Model |
       Scenario Predictor | Map Simulation | Real Data
All scenarios are NOTIONAL. The protective 'hybrid' unit is a generic black box.
"""
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from sklearn.base import clone
from sklearn.calibration import calibration_curve
from sklearn.metrics import confusion_matrix, precision_recall_curve, roc_curve
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

import data_prep
import simulate
import train

ROOT = Path(__file__).parent
DATA, MODELS, RESULTS = ROOT / "data", ROOT / "models", ROOT / "results"
NUM, CAT, ALL = data_prep.NUM_FEATURES, data_prep.CAT_FEATURES, data_prep.ALL_FEATURES
MODES = simulate.MODES

st.set_page_config(page_title="SKYSHIELD | Survivability Lab", page_icon="🛰️", layout="wide")

# --------------------------------------------------------------------------- HUD theme
import html as _html
import plotly.io as pio

GREEN, CYAN, RED, AMBER = "#00ff9c", "#00e5ff", "#ff3d3d", "#ffab00"

pio.templates["aegis"] = go.layout.Template(layout=go.Layout(
    paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="#08121a",
    font=dict(color="#bfe3d2", family="Share Tech Mono, Consolas, monospace"),
    colorway=[GREEN, CYAN, AMBER, RED, "#b388ff", "#69f0ae", "#ffd740", "#40c4ff"],
    xaxis=dict(gridcolor="#12303a", zerolinecolor="#12303a", linecolor="#1d5a4a"),
    yaxis=dict(gridcolor="#12303a", zerolinecolor="#12303a", linecolor="#1d5a4a"),
    legend=dict(bgcolor="rgba(8,18,26,0.7)", bordercolor="#12404a", borderwidth=1),
    title=dict(font=dict(color=GREEN)),
))
pio.templates.default = "plotly_dark+aegis"

CSS = """
@import url('https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Rajdhani:wght@500;700&display=swap');
html, body, [class*="css"], .stApp { font-family: 'Share Tech Mono', Consolas, monospace; }
.stApp { background: radial-gradient(ellipse at top, #0a1a22 0%, #05090d 60%); }
.stApp::before { content:""; position:fixed; inset:0; pointer-events:none; z-index:999;
  background: repeating-linear-gradient(0deg, rgba(0,255,156,0.025) 0px, rgba(0,255,156,0.025) 1px, transparent 1px, transparent 3px); }
#MainMenu, footer { visibility: hidden; }
h1, h2, h3 { font-family: 'Rajdhani', sans-serif !important; letter-spacing: 2px; text-transform: uppercase; color: #00ff9c; }
.hud { border: 1px solid #12404a; border-left: 4px solid #00ff9c; background: linear-gradient(90deg, rgba(0,255,156,0.08), rgba(0,0,0,0));
  padding: 10px 18px 2px 18px; margin-bottom: 14px; }
.hud h1 { margin: 2px 0 8px 0; font-size: 2rem; }
.hud-top { font-size: 0.75rem; color: #6fbf9f; letter-spacing: 2px; }
.dot { display:inline-block; width:9px; height:9px; border-radius:50%; background:#00ff9c; margin-right:6px; box-shadow:0 0 8px #00ff9c; animation: blink 1.4s infinite; }
@keyframes blink { 50% { opacity: 0.2; } }
[data-testid="stMetric"] { background:#0b141b; border:1px solid #12404a; border-left:3px solid #00ff9c; padding:10px 14px; border-radius:3px; }
[data-testid="stMetricValue"] { color:#00ff9c; font-family:'Rajdhani',sans-serif; }
[data-testid="stSidebar"] { background:#060d12; border-right:1px solid #12404a; }
.stButton > button { border:1px solid #00ff9c; background:#06251c; color:#00ff9c; letter-spacing:1px; text-transform:uppercase; }
.stButton > button:hover { background:#00ff9c; color:#04100c; }
.stTabs [data-baseweb="tab"] { letter-spacing:1px; text-transform:uppercase; }
.brand { font-family:'Rajdhani',sans-serif; font-size:1.35rem; color:#00ff9c; letter-spacing:3px; border-bottom:1px solid #12404a; padding-bottom:8px; margin-bottom:10px; }
.brand small { display:block; font-size:0.65rem; color:#6fbf9f; letter-spacing:2px; }
.chip { display:inline-block; border:1px solid; padding:3px 12px; margin:0 8px 8px 0; font-size:0.8rem; letter-spacing:2px; border-radius:2px; background:rgba(0,0,0,0.35); }
.ov { display:flex; gap:28px; align-items:center; flex-wrap:wrap; margin:6px 0 18px 0; }
.tiles { display:grid; grid-template-columns:repeat(2, minmax(190px, 1fr)); gap:10px; flex:1; }
.tile { background:#0b141b; border:1px solid #12404a; border-top:2px solid #00ff9c; padding:10px 14px; }
.tl { font-size:0.7rem; color:#6fbf9f; letter-spacing:2px; }
.tv { font-family:'Rajdhani',sans-serif; font-size:1.5rem; color:#00ff9c; }
.radar { position:relative; width:230px; height:230px; border-radius:50%; border:2px solid #00ff9c; overflow:hidden; background:#04100c;
  box-shadow:0 0 22px rgba(0,255,156,0.35), inset 0 0 30px rgba(0,255,156,0.15);
  background-image: repeating-radial-gradient(circle, transparent 0px, transparent 37px, rgba(0,255,156,0.35) 38px, transparent 39px),
  linear-gradient(0deg, transparent 49.6%, rgba(0,255,156,0.3) 50%, transparent 50.4%), linear-gradient(90deg, transparent 49.6%, rgba(0,255,156,0.3) 50%, transparent 50.4%); }
.sweep { position:absolute; inset:0; border-radius:50%; background:conic-gradient(from 0deg, rgba(0,255,156,0.6), rgba(0,255,156,0) 65deg, transparent 65deg); animation:spin 4s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }
.blip { position:absolute; width:8px; height:8px; border-radius:50%; background:#ff3d3d; box-shadow:0 0 8px #ff3d3d; animation:ping 4s infinite; }
.b1 { top:30%; left:62%; animation-delay:0.4s; } .b2 { top:66%; left:30%; animation-delay:1.9s; } .b3 { top:44%; left:78%; animation-delay:3s; }
@keyframes ping { 0%,100% { opacity:0; } 8% { opacity:1; } 60% { opacity:0.1; } }
"""
st.markdown(f"<style>{CSS}</style>", unsafe_allow_html=True)


def hud_header(title, sub="SIMULATION // NOTIONAL DATA // EDUCATIONAL USE ONLY"):
    st.markdown(f"<div class='hud'><div class='hud-top'><span class='dot'></span>SYSTEM ONLINE &nbsp;|&nbsp; "
                f"{_html.escape(sub)}</div><h1>{_html.escape(title)}</h1></div>", unsafe_allow_html=True)


def chip(text, color):
    return f"<span class='chip' style='border-color:{color};color:{color}'>{_html.escape(text)}</span>"


def threat_level(p):
    """Higher survival chance = calmer board. p = predicted P(survive)."""
    if p >= 0.70:
        return "THREAT LEVEL: LOW", GREEN
    if p >= 0.50:
        return "THREAT LEVEL: ELEVATED", AMBER
    return "THREAT LEVEL: CRITICAL", RED


def overview_radar():
    m = load_csv(RESULTS / "metrics.csv")
    t = m[m.stage == "tuned"].sort_values("f1", ascending=False)
    n_rows = len(load_csv(DATA / "cleaned.csv"))
    tiles = [("MODELS ONLINE", len(t)), ("ENGAGEMENTS LOGGED", f"{n_rows:,}"),
             ("TOP CLASSIFIER (F1)", t.model.iloc[0].upper()), ("BEST F1 / BEST AUC", f"{t.f1.iloc[0]:.3f} / {t.roc_auc.max():.3f}")]
    tiles_html = "".join(f"<div class='tile'><div class='tl'>{a}</div><div class='tv'>{b}</div></div>" for a, b in tiles)
    st.markdown("<div class='ov'><div class='radar'><div class='sweep'></div><div class='blip b1'></div>"
                "<div class='blip b2'></div><div class='blip b3'></div></div>"
                f"<div class='tiles'>{tiles_html}</div></div>", unsafe_allow_html=True)


def anim_controls(n):
    """Play / pause buttons and a scrub slider for a frame animation with n frames."""
    menus = [dict(type="buttons", x=0.02, y=0.98, bgcolor="#06251c", font=dict(color=GREEN), buttons=[
        dict(label="▶ PLAY", method="animate",
             args=[None, {"frame": {"duration": 110, "redraw": True}, "fromcurrent": True}]),
        dict(label="⏸ PAUSE", method="animate",
             args=[[None], {"frame": {"duration": 0, "redraw": False}, "mode": "immediate"}])])]
    sliders = [dict(active=0, pad=dict(t=0), font=dict(color="#6fbf9f"), steps=[
        dict(method="animate", label=str(i),
             args=[[str(i)], {"mode": "immediate", "frame": {"duration": 0, "redraw": True}}])
        for i in range(n)])]
    return menus, sliders


def radar_scope(rng_km, heading, threat_bearing, n_dec, survived):
    """Polar PPI-style scope: own aircraft at the centre, notional contact closing in."""
    N = 40
    rr = np.random.default_rng(7)
    k = max(n_dec, 1)
    dec_theta = (heading + 180 + rr.uniform(-40, 40, k)) % 360
    dec_r = rr.uniform(0.08, 0.3, k) * rng_km

    def traces(i):
        f, end = i / (N - 1), i == N - 1
        sweep = (i * 18) % 360
        show_dec = bool(n_dec) and f > 0.5
        return [
            go.Scatterpolar(r=[0, rng_km], theta=[sweep, sweep], mode="lines",
                            line=dict(color=GREEN, width=3), name="Sweep"),
            go.Scatterpolar(r=[] if end else [rng_km * (1 - f)], theta=[] if end else [threat_bearing],
                            mode="markers", marker=dict(size=13, color=RED, symbol="diamond"),
                            name="Contact"),
            go.Scatterpolar(r=dec_r if show_dec else [], theta=dec_theta if show_dec else [],
                            mode="markers", marker=dict(size=7, color=AMBER), name="Decoys"),
            go.Scatterpolar(r=[0], theta=[0], mode="markers+text",
                            marker=dict(size=15, color=(GREEN if survived else RED) if end else CYAN),
                            text=[("SURVIVED" if survived else "HIT") if end else "OWN"],
                            textposition="top center", textfont=dict(color="#e8fff5"), name="Own aircraft"),
        ]

    fig = go.Figure(data=traces(0) + [go.Scatterpolar(
        r=[0, rng_km * 0.3], theta=[heading, heading], mode="lines",
        line=dict(color=CYAN, width=2, dash="dot"), name="Heading")])
    fig.frames = [go.Frame(data=traces(i), traces=[0, 1, 2, 3], name=str(i)) for i in range(N)]
    menus, sliders = anim_controls(N)
    ticks = [rng_km * q / 4 for q in (1, 2, 3, 4)]
    fig.update_layout(
        height=620, margin=dict(l=30, r=30, t=50, b=10), updatemenus=menus, sliders=sliders,
        title="PPI SCOPE  |  NORTH UP  |  RINGS = RANGE (km)",
        polar=dict(bgcolor="#04100c",
                   radialaxis=dict(range=[0, rng_km], tickvals=ticks, ticktext=[f"{t:.0f}" for t in ticks],
                                   gridcolor="#0f5f43", linecolor="#0f5f43", tickfont=dict(color="#6fbf9f"),
                                   angle=45),
                   angularaxis=dict(direction="clockwise", rotation=90, gridcolor="#0f5f43",
                                    linecolor="#0f5f43", tickfont=dict(color="#6fbf9f"))))
    return fig


def ring_trace(E, radius_km):
    pts = [destination(E[0], E[1], b, radius_km) for b in range(0, 361, 5)]
    return MapScatter(lat=[p[0] for p in pts], lon=[p[1] for p in pts], mode="lines",
                      line=dict(width=1, color="rgba(0,255,156,0.45)"), hoverinfo="skip",
                      name=f"{radius_km:.0f} km ring", showlegend=False)



# --------------------------------------------------------------------------- loading
def ensure_artifacts():
    """First run on a fresh deployment: build data + models automatically."""
    if not (RESULTS / "metrics.csv").exists():
        with st.spinner("First run: generating simulated data and training models (about a minute)..."):
            simulate.run()
            train.main()


@st.cache_data
def load_csv(path):
    return pd.read_csv(path)


@st.cache_resource
def load_model(name):
    return joblib.load(MODELS / f"{train.slug(name)}.joblib")


def model_names():
    m = load_csv(RESULTS / "metrics.csv")
    return list(m["model"].unique())


def scenario_row(mode, rng_km, speed, alt, warn, diff, clutter, n_units):
    return {"engagement_range_km": rng_km, "aircraft_speed_mps": speed, "altitude_km": alt,
            "warning_time_s": warn, "threat_difficulty": diff, "weather_clutter": clutter,
            "n_measures": simulate.effective_measures(mode, n_units), "protection_mode": mode}


def predict_p(model, rows):
    return model.predict_proba(pd.DataFrame(rows)[ALL])[:, 1]


def scenario_sliders(key):
    c1, c2 = st.columns(2)
    with c1:
        rng_km = st.slider("Engagement range (km)", 5.0, 80.0, 35.0, key=f"{key}r")
        speed = st.slider("Aircraft speed (m/s)", 100.0, 350.0, 230.0, key=f"{key}s")
        alt = st.slider("Altitude (km)", 0.3, 13.0, 8.0, key=f"{key}a")
        n_units = st.slider("Protective units deployed (decoy/hybrid)", 1, 6, 3, key=f"{key}n")
    with c2:
        warn = st.slider("Warning time (s)", 2.0, 40.0, 18.0, key=f"{key}w")
        diff = st.slider("Threat difficulty index (0-1, abstract)", 0.0, 1.0, 0.5, key=f"{key}d")
        clutter = st.slider("Weather / clutter (0-1)", 0.0, 1.0, 0.3, key=f"{key}c")
    return rng_km, speed, alt, warn, diff, clutter, n_units


# --------------------------------------------------------------------------- pages
def page_overview():
    hud_header("Aircraft Survivability // ML Command Console")
    overview_radar()
    st.markdown("""
A **software-only study**: a Monte Carlo simulator produces labelled outcomes
(*survived* / *hit*) for notional aircraft engagements under four protection modes
(**none, decoy, manoeuvre, hybrid**). Several ML models are trained on that data and compared.

**Honesty box:** no public dataset of real engagement outcomes exists. All probabilities
inside the simulator are *assumptions*, so results describe the model, not any real
system. The hybrid unit is a generic black box (detect with probability *p*,
neutralise with probability *q*); no weapon or interceptor design is modelled.
""")
    st.subheader("How this maps to the mini-project rubric")
    st.table(pd.DataFrame({
        "Rubric item": ["Data cleaning & splitting", "Models comparison & analytics",
                        "UI deployment & accessibility", "Code quality, GitHub, report"],
        "Where to see it": ["Data & Cleaning page, data_prep.py",
                            "Model Comparison + Understand a Model pages, train.py",
                            "This app (runs in any browser; deploy on Streamlit Community Cloud)",
                            "README.md, modular .py files, 10-page report"]}))


def page_data():
    hud_header("Data & Cleaning")
    raw = load_csv(DATA / "raw_simulated.csv")
    clean = load_csv(DATA / "cleaned.csv")
    rep = json.load(open(RESULTS / "cleaning_report.json"))
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Raw rows", rep["rows_raw"])
    c2.metric("Duplicates removed", rep["duplicates_removed"])
    c3.metric("Invalid values → NaN", sum(rep["invalid_values_set_to_nan"].values()))
    c4.metric("Clean rows", rep["rows_clean"])
    st.info("Median imputation, scaling and one-hot encoding happen **inside the model pipeline**, "
            "fitted on the training split only (80/20 stratified), so there is no data leakage. "
            "The simulator's own probability column was dropped as a leakage column.")
    with st.expander("Cleaning report (JSON)"):
        st.json(rep)
    tab1, tab2, tab3, tab4 = st.tabs(["Raw sample", "Distributions", "Survival by mode", "Correlation"])
    with tab1:
        st.dataframe(raw.head(30))
        miss = raw.isna().sum()
        st.plotly_chart(px.bar(miss[miss > 0], title="Missing values in raw data",
                               labels={"value": "count", "index": "column"}), use_container_width=True)
        both = pd.concat([raw.assign(data="raw")[["aircraft_speed_mps", "data"]],
                          clean.assign(data="cleaned")[["aircraft_speed_mps", "data"]]])
        st.plotly_chart(px.box(both, x="data", y="aircraft_speed_mps",
                               title="Outlier handling: aircraft speed before vs after"),
                        use_container_width=True)
    with tab2:
        col = st.selectbox("Feature", NUM)
        st.plotly_chart(px.histogram(clean, x=col, color=clean["survived"].map({1: "Survived", 0: "Hit"}),
                                     barmode="overlay", opacity=0.6, nbins=40,
                                     labels={"color": "Outcome"}), use_container_width=True)
    with tab3:
        g = clean.groupby("protection_mode")["survived"].mean().reindex(MODES).reset_index()
        st.plotly_chart(px.bar(g, x="protection_mode", y="survived", text_auto=".2f",
                               title="Empirical survival rate by protection mode"),
                        use_container_width=True)
    with tab4:
        st.plotly_chart(px.imshow(clean[NUM + ["survived"]].corr(), text_auto=".2f",
                                  color_continuous_scale="RdBu", zmin=-1, zmax=1),
                        use_container_width=True)


def page_models():
    hud_header("Model Comparison")
    m = load_csv(RESULTS / "metrics.csv")
    preds = load_csv(RESULTS / "test_predictions.csv")
    imp = load_csv(RESULTS / "perm_importance.csv")
    params = json.load(open(RESULTS / "best_params.json"))
    y = preds["y_true"].to_numpy()
    names = model_names()
    tuned = m[m.stage == "tuned"].sort_values("f1", ascending=False)

    t1, t2, t3, t4, t5, t6 = st.tabs(["Metrics table", "Metric bars", "Baseline vs tuned",
                                      "ROC & PR curves", "Confusion & calibration", "Feature importance"])
    with t1:
        st.dataframe(tuned.drop(columns="stage").round(3), use_container_width=True)
        st.caption("Positive class = aircraft survived. Test set = 20% stratified hold-out. "
                   "cv_f1 = 3-fold CV score of the tuned model on the training set.")
        st.subheader("Best hyper-parameters (GridSearchCV, scoring = F1)")
        st.json(params)
    with t2:
        long = tuned.melt(id_vars="model", value_vars=["accuracy", "precision", "recall", "f1", "roc_auc"])
        st.plotly_chart(px.bar(long, x="model", y="value", color="variable", barmode="group"),
                        use_container_width=True)
    with t3:
        metric = st.selectbox("Metric", ["f1", "accuracy", "roc_auc", "precision", "recall"])
        st.plotly_chart(px.bar(m, x="model", y=metric, color="stage", barmode="group"),
                        use_container_width=True)
        st.dataframe(m[["model", "stage", "fit_seconds"]].pivot(index="model", columns="stage",
                                                                values="fit_seconds"))
    with t4:
        a, b = st.columns(2)
        fig = go.Figure()
        for n in names:
            fpr, tpr, _ = roc_curve(y, preds[f"proba_{n}"])
            fig.add_trace(go.Scatter(x=fpr, y=tpr, name=n, mode="lines"))
        fig.add_trace(go.Scatter(x=[0, 1], y=[0, 1], name="chance", line=dict(dash="dash", color="grey")))
        fig.update_layout(title="ROC curves", xaxis_title="False positive rate",
                          yaxis_title="True positive rate")
        a.plotly_chart(fig, use_container_width=True)
        fig = go.Figure()
        for n in names:
            p, r, _ = precision_recall_curve(y, preds[f"proba_{n}"])
            fig.add_trace(go.Scatter(x=r, y=p, name=n, mode="lines"))
        fig.update_layout(title="Precision-recall curves", xaxis_title="Recall", yaxis_title="Precision")
        b.plotly_chart(fig, use_container_width=True)
    with t5:
        sel = st.selectbox("Model", names, key="cm_model")
        thr = st.slider("Decision threshold", 0.1, 0.9, 0.5, 0.05)
        p = preds[f"proba_{sel}"].to_numpy()
        cm = confusion_matrix(y, (p >= thr).astype(int))
        a, b = st.columns(2)
        a.plotly_chart(px.imshow(cm, text_auto=True, x=["Pred Hit", "Pred Survived"],
                                 y=["True Hit", "True Survived"], color_continuous_scale="Blues",
                                 title=f"Confusion matrix: {sel}"), use_container_width=True)
        frac, mean = calibration_curve(y, p, n_bins=10)
        fig = go.Figure([go.Scatter(x=mean, y=frac, mode="lines+markers", name=sel),
                         go.Scatter(x=[0, 1], y=[0, 1], line=dict(dash="dash", color="grey"),
                                    name="perfect")])
        fig.update_layout(title="Calibration (reliability) curve",
                          xaxis_title="Predicted probability", yaxis_title="Observed survival rate")
        b.plotly_chart(fig, use_container_width=True)
    with t6:
        sel = st.selectbox("Model", names, key="imp_model")
        d = imp[imp.model == sel].sort_values("importance")
        st.plotly_chart(px.bar(d, x="importance", y="feature", error_x="std", orientation="h",
                               title=f"Permutation importance (drop in ROC-AUC): {sel}"),
                        use_container_width=True)
        heat = imp.pivot(index="feature", columns="model", values="importance")
        st.plotly_chart(px.imshow(heat, text_auto=".2f", color_continuous_scale="Viridis",
                                  title="Importance across all models"), use_container_width=True)


MODEL_INFO = {
    "Logistic Regression": ("Fits one straight-line boundary and turns the distance from it into a probability.",
                            "Fast, easy to interpret.", "Cannot bend around curved patterns."),
    "Naive Bayes": ("Multiplies per-feature likelihoods assuming features are independent.",
                    "Very fast, works with little data.", "Independence assumption is wrong here (protection mode interacts with warning time)."),
    "SVM": ("Finds the boundary with the widest margin; kernels let it curve.",
            "Strong on smooth boundaries.", "Slower on large data; C and kernel need tuning."),
    "KNN": ("Looks at the k most similar training scenarios and votes.",
            "No training step, flexible.", "Slow at prediction time, sensitive to scaling and noise."),
    "Decision Tree": ("Asks a chain of yes/no questions on features.",
                      "Fully readable rules.", "Overfits easily; blocky boundaries."),
    "Random Forest": ("Averages many trees trained on random subsets.",
                      "Robust, handles interactions.", "Less interpretable than one tree."),
    "AdaBoost": ("Trains small trees in sequence, each focusing on earlier mistakes.",
                 "Good accuracy with simple learners.", "Sensitive to noisy labels."),
    "XGBoost": ("Gradient-boosted trees with regularisation.",
                "Often the strongest on tabular data.", "Many hyper-parameters."),
    "Gradient Boosting": ("Trees added one by one, each correcting the residual errors.",
                          "Strong on tabular data.", "Slower to tune than a forest."),
}


@st.cache_data
def boundary_grid(name, f1, f2, params_json):
    train_df = pd.read_csv(DATA / "train.csv")
    sub = train_df.sample(min(1500, len(train_df)), random_state=0)
    est = clone(train.build_models()[name][0])
    est.set_params(**{k.split("__", 1)[1]: v for k, v in json.loads(params_json).items()})
    pipe2 = make_pipeline(StandardScaler(), est).fit(sub[[f1, f2]].fillna(sub[[f1, f2]].median()), sub["survived"])
    x = np.linspace(sub[f1].min(), sub[f1].max(), 80)
    yv = np.linspace(sub[f2].min(), sub[f2].max(), 80)
    xx, yy = np.meshgrid(x, yv)
    zz = pipe2.predict_proba(pd.DataFrame({f1: xx.ravel(), f2: yy.ravel()}))[:, 1].reshape(xx.shape)
    return x, yv, zz, sub[[f1, f2, "survived"]]


def page_understand():
    hud_header("Understand a Model")
    names = model_names()
    sel = st.selectbox("Model", names)
    how, pro, con = MODEL_INFO.get(sel, ("", "", ""))
    st.markdown(f"**How it works:** {how}  \n**Strength:** {pro}  \n**Weakness:** {con}")
    params = json.load(open(RESULTS / "best_params.json"))[sel]
    st.caption(f"Tuned hyper-parameters: {params}")

    st.subheader("Decision boundary on two features")
    st.caption("The model is refit on just the two chosen features so the boundary can be drawn. "
               "Colour = predicted survival probability; dots = real training scenarios.")
    c1, c2 = st.columns(2)
    f1 = c1.selectbox("X feature", NUM, index=3)
    f2 = c2.selectbox("Y feature", [c for c in NUM if c != f1], index=3)
    x, yv, zz, pts = boundary_grid(sel, f1, f2, json.dumps(params))
    fig = go.Figure(go.Contour(x=x, y=yv, z=zz, colorscale="RdYlGn", zmin=0, zmax=1,
                               colorbar=dict(title="P(survive)"), opacity=0.8, contours_coloring="heatmap"))
    fig.add_trace(go.Scatter(x=pts[f1], y=pts[f2], mode="markers",
                             marker=dict(size=4, color=pts["survived"].map({1: "#1b5e20", 0: "#ff1744"}),
                                         line=dict(width=0.3, color="white")), name="training data"))
    fig.update_layout(xaxis_title=f1, yaxis_title=f2, height=520)
    st.plotly_chart(fig, use_container_width=True)

    if sel == "Decision Tree" and (RESULTS / "decision_tree.png").exists():
        st.subheader("The tuned tree (top 3 levels)")
        st.image(str(RESULTS / "decision_tree.png"))


def page_predictor():
    hud_header("Scenario Predictor")
    model = load_model(st.selectbox("Model", model_names()))
    rng_km, speed, alt, warn, diff, clutter, n_units = scenario_sliders("pp")
    rows = [scenario_row(m, rng_km, speed, alt, warn, diff, clutter, n_units) for m in MODES]
    probs = predict_p(model, rows)
    cols = st.columns(4)
    for c, m, p in zip(cols, MODES, probs):
        c.metric(m.capitalize(), f"{p:.1%}", f"{p - probs[0]:+.1%} vs none" if m != "none" else None)
    st.subheader("Sensitivity: how survival changes as one factor varies")
    ranges = {"engagement_range_km": (5, 80), "warning_time_s": (2, 40),
              "threat_difficulty": (0, 1), "weather_clutter": (0, 1), "aircraft_speed_mps": (100, 350)}
    var = st.selectbox("Vary", list(ranges))
    grid = np.linspace(*ranges[var], 40)
    base = dict(engagement_range_km=rng_km, aircraft_speed_mps=speed, altitude_km=alt, warning_time_s=warn,
                threat_difficulty=diff, weather_clutter=clutter)
    fig = go.Figure()
    for m in MODES:
        rr = []
        for g in grid:
            d = {**base, var: g}
            rr.append(scenario_row(m, d["engagement_range_km"], d["aircraft_speed_mps"], d["altitude_km"],
                                   d["warning_time_s"], d["threat_difficulty"], d["weather_clutter"], n_units))
        fig.add_trace(go.Scatter(x=grid, y=predict_p(model, rr), name=m, mode="lines"))
    fig.update_layout(xaxis_title=var, yaxis_title="Predicted P(survive)", yaxis_range=[0, 1])
    st.plotly_chart(fig, use_container_width=True)
    st.caption("The 'hybrid' curve reflects an ASSUMED detect/neutralise probability in simulate.py.")


# --------------------------------------------------------------------------- map
def destination(lat, lon, bearing, dist_km):
    R = 6371.0
    b, d = np.radians(bearing), dist_km / R
    la1, lo1 = np.radians(lat), np.radians(lon)
    la2 = np.arcsin(np.sin(la1) * np.cos(d) + np.cos(la1) * np.sin(d) * np.cos(b))
    lo2 = lo1 + np.arctan2(np.sin(b) * np.sin(d) * np.cos(la1), np.cos(d) - np.sin(la1) * np.sin(la2))
    return float(np.degrees(la2)), float(np.degrees(lo2))


NEW_MAP = hasattr(go, "Scattermap")
MapScatter = go.Scattermap if NEW_MAP else go.Scattermapbox


def build_map(E, heading, threat_bearing, rng_km, mode, n_dec, survived, p):
    N = 40
    A0 = destination(*E, (heading + 180) % 360, max(rng_km * 0.6, 5))
    T0 = destination(*E, threat_bearing, rng_km)
    s = np.linspace(0, 1, N)
    ac_lat = A0[0] + (E[0] - A0[0]) * s
    ac_lon = A0[1] + (E[1] - A0[1]) * s
    if mode in ("maneuver", "hybrid"):      # visual weave, ends exactly at E
        amp = 0.04 * rng_km / 50
        weave = np.where(s > 0.5, amp * np.sin(6 * np.pi * (s - 0.5)) * (1 - s) * 2, 0)
        ac_lat = ac_lat + weave
    th_lat = T0[0] + (E[0] - T0[0]) * s
    th_lon = T0[1] + (E[1] - T0[1]) * s

    def frame_traces(i):
        dec_lat, dec_lon = [], []
        if mode in ("decoy", "hybrid") and i >= N // 2:
            for k in range(n_dec):
                j = max(i - 3 * (k + 1), 0)
                dec_lat.append(ac_lat[j]); dec_lon.append(ac_lon[j] + 0.01 * (k + 1))
        pu_lat, pu_lon = [], []
        if mode == "hybrid" and i >= N // 2:    # purely visual: abstract protective unit
            f = (i - N // 2) / (N - 1 - N // 2)
            pu_lat = [ac_lat[N // 2] + (th_lat[N - 6] - ac_lat[N // 2]) * f]
            pu_lon = [ac_lon[N // 2] + (th_lon[N - 6] - ac_lon[N // 2]) * f]
        end = i == N - 1
        return [
            MapScatter(lat=[ac_lat[i]], lon=[ac_lon[i]], mode="markers",
                       marker=dict(size=16, color="#00e5ff"), name="Aircraft"),
            MapScatter(lat=[th_lat[i]] if not end else [], lon=[th_lon[i]] if not end else [],
                       mode="markers", marker=dict(size=13, color="#ff3d3d"), name="Notional threat"),
            MapScatter(lat=dec_lat, lon=dec_lon, mode="markers",
                       marker=dict(size=9, color="#ffab00"), name="Decoys"),
            MapScatter(lat=pu_lat, lon=pu_lon, mode="markers",
                       marker=dict(size=11, color="#00ff9c"), name="Protective unit (abstract)"),
            MapScatter(lat=[E[0]] if end else [], lon=[E[1]] if end else [], mode="markers+text",
                       marker=dict(size=26, color="#00e676" if survived else "#ff1744"),
                       text=["SURVIVED" if survived else "HIT"], textposition="top right",
                       name="Outcome"),
        ]

    base = [MapScatter(lat=ac_lat, lon=ac_lon, mode="lines", line=dict(width=2, color="#00e5ff"),
                       name="Aircraft track"),
            MapScatter(lat=th_lat, lon=th_lon, mode="lines", line=dict(width=2, color="#ff3d3d"),
                       name="Threat track")]
    rings = [ring_trace(E, rng_km * q) for q in (0.33, 0.66, 1.0)]
    fig = go.Figure(data=base + frame_traces(0) + rings)
    fig.frames = [go.Frame(data=frame_traces(i), traces=[2, 3, 4, 5, 6], name=str(i)) for i in range(N)]
    width_km = 3 * max(rng_km, 5)
    zoom = float(np.clip(np.log2(54787 * np.cos(np.radians(E[0])) / width_km), 3, 11))
    layout_map = dict(style="carto-darkmatter", center=dict(lat=E[0], lon=E[1]), zoom=zoom)
    fig.update_layout(**({"map": layout_map} if NEW_MAP else {"mapbox": layout_map}))
    fig.update_layout(
        height=620, margin=dict(l=0, r=0, t=40, b=0),
        title=f"Mode: {mode} | model P(survive) = {p:.1%}",
        updatemenus=[dict(type="buttons", x=0.02, y=0.98, buttons=[
            dict(label="▶ Play", method="animate",
                 args=[None, {"frame": {"duration": 120, "redraw": True}, "fromcurrent": True}]),
            dict(label="⏸ Pause", method="animate",
                 args=[[None], {"frame": {"duration": 0, "redraw": False}, "mode": "immediate"}])])],
        sliders=[dict(active=0, pad=dict(t=0), steps=[
            dict(method="animate", label=str(i),
                 args=[[str(i)], {"mode": "immediate", "frame": {"duration": 0, "redraw": True}}])
            for i in range(N)])])
    return fig


def page_map():
    hud_header("Tactical Map Simulation")
    st.caption("Positions are an illustration on a real map; geometry is not to scale in time and "
               "no real system is represented.")
    names = model_names()
    model = load_model(st.selectbox("Model that predicts survival", names))
    mode = st.radio("Protection mode", MODES, horizontal=True, index=3)
    rng_km, speed, alt, warn, diff, clutter, n_units = scenario_sliders("mp")
    c1, c2, c3, c4 = st.columns(4)
    lat = c1.number_input("Engagement point latitude", value=21.1458, format="%.4f")
    lon = c2.number_input("Engagement point longitude", value=79.0882, format="%.4f")
    heading = c3.slider("Aircraft heading (deg)", 0, 359, 60)
    t_bear = c4.slider("Threat bearing from point (deg)", 0, 359, 200)
    p = float(predict_p(model, [scenario_row(mode, rng_km, speed, alt, warn, diff, clutter, n_units)])[0])
    if "seed" not in st.session_state:
        st.session_state.seed = 0
    if st.button("🎲 Run a new engagement"):
        st.session_state.seed += 1
    survived = bool(np.random.default_rng(st.session_state.seed).random() < p)
    st.metric("Predicted survival probability", f"{p:.1%}",
              "this run: survived" if survived else "this run: hit")
    n_dec = n_units if mode in ("decoy", "hybrid") else 0
    label, colour = threat_level(p)
    st.markdown(chip(label, colour) + chip("MODE: " + mode.upper(), CYAN)
                + chip("LAST RUN: " + ("SURVIVED" if survived else "HIT"), GREEN if survived else RED),
                unsafe_allow_html=True)
    tab_map, tab_scope = st.tabs(["TACTICAL MAP", "RADAR SCOPE"])
    with tab_map:
        st.plotly_chart(build_map((lat, lon), heading, t_bear, rng_km, mode, n_dec, survived, p),
                        use_container_width=True)
    with tab_scope:
        st.plotly_chart(radar_scope(rng_km, heading, t_bear, n_dec, survived), use_container_width=True)
    st.caption("Each click on 'Run a new engagement' is one Monte Carlo draw from the model's "
               "probability. Over many runs the survival rate converges to the predicted value.")


# --------------------------------------------------------------------------- real data
def page_real():
    hud_header("Real Data")
    st.markdown("""
No public data of real engagement outcomes exists, so **outcomes stay simulated**. What *can* be real is the
**aircraft side**: speed and altitude from public ADS-B flight data
([OpenSky Network](https://opensky-network.org/data), also several Kaggle flight-track datasets).
Upload a CSV below to (1) draw a real track on the map and (2) score survival along it, or
regenerate the training data with `python simulate.py --real-csv yourfile.csv` so training uses real kinematics.
""")
    c1, c2 = st.columns(2)
    su = c1.selectbox("Speed unit in file", ["m/s", "knots", "km/h"])
    au = c2.selectbox("Altitude unit in file", ["m", "ft", "km"])
    up = st.file_uploader("Flight CSV (needs lat, lon, speed and altitude columns)", type="csv")
    if up is not None:
        try:
            trk = simulate.normalise_flight_csv(pd.read_csv(up), su, au)
        except ValueError as e:
            st.error(str(e)); return
        if trk[["lat", "lon"]].isna().all().all():
            st.error("No lat/lon columns found."); return
        trk = trk.dropna(subset=["lat", "lon"])
        st.success(f"{len(trk)} usable points")
    else:
        st.info("No file uploaded: showing a SYNTHETIC demo track.")
        t = np.linspace(0, 1, 120)
        trk = pd.DataFrame({"lat": 19 + 4 * t, "lon": 74 + 8 * t, "speed_mps": 230 + 20 * np.sin(6 * t),
                            "altitude_km": 3 + 8 * np.sin(np.pi * t)})
    if len(trk) > 300:
        trk = trk.iloc[np.linspace(0, len(trk) - 1, 300).astype(int)]
    model = load_model(st.selectbox("Model", model_names()))
    mode = st.radio("Protection mode", MODES, horizontal=True, index=3, key="rm")
    rng_km, _, _, warn, diff, clutter, n_units = scenario_sliders("rd")
    rows = [scenario_row(mode, rng_km, r.speed_mps, r.altitude_km, warn, diff, clutter, n_units)
            for r in trk.itertuples()]
    trk = trk.assign(p_survive=predict_p(model, rows))
    fig = go.Figure(MapScatter(lat=trk.lat, lon=trk.lon, mode="markers+lines",
                               marker=dict(size=8, color=trk.p_survive, colorscale="RdYlGn", cmin=0, cmax=1,
                                           colorbar=dict(title="P(survive)")),
                               line=dict(width=1, color="grey"), name="track"))
    lm = dict(style="carto-darkmatter", center=dict(lat=trk.lat.mean(), lon=trk.lon.mean()), zoom=5)
    fig.update_layout(**({"map": lm} if NEW_MAP else {"mapbox": lm}), height=560, margin=dict(l=0, r=0, t=0, b=0))
    st.plotly_chart(fig, use_container_width=True)
    st.plotly_chart(px.line(trk.reset_index(drop=True), y=["speed_mps", "altitude_km", "p_survive"],
                            title="Along the track"), use_container_width=True)


# --------------------------------------------------------------------------- router
ensure_artifacts()
PAGES = {"◉ Command Overview": page_overview, "▤ Data & Cleaning": page_data,
         "▦ Model Comparison": page_models, "◈ Understand a Model": page_understand,
         "⌖ Scenario Predictor": page_predictor, "✈ Tactical Map": page_map, "⌁ Real Data": page_real}
st.sidebar.markdown("<div class='brand'>SKYSHIELD<small>SURVIVABILITY ANALYTICS LAB</small></div>", unsafe_allow_html=True)
choice = st.sidebar.radio("Navigation", list(PAGES))
st.sidebar.markdown(chip("SIMULATION", AMBER) + chip("NOTIONAL DATA", CYAN), unsafe_allow_html=True)
st.sidebar.caption("Educational study only. No real system is modelled.")
PAGES[choice]()
