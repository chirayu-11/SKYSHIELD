"""
train.py - trains and compares the models (rubric item 2).

    python train.py

Outputs
    data/cleaned.csv, data/train.csv, data/test.csv
    models/<model>.joblib                (tuned pipelines: preprocessing + classifier)
    results/metrics.csv                  (baseline AND tuned metrics per model)
    results/best_params.json
    results/test_predictions.csv         (y_true + predicted probability per model)
    results/perm_importance.csv          (permutation importance on the test set)
    results/cleaning_report.json, results/decision_tree.png
"""
import json
import time
import warnings
from pathlib import Path

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.ensemble import AdaBoostClassifier, GradientBoostingClassifier, RandomForestClassifier
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, f1_score, precision_score, recall_score,
                             roc_auc_score)
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier, plot_tree

import data_prep
import simulate

warnings.filterwarnings("ignore")
ROOT = Path(__file__).parent
DATA, MODELS, RESULTS = ROOT / "data", ROOT / "models", ROOT / "results"
SEED = 42


def slug(name):
    return name.lower().replace(" ", "_")


def build_models():
    """name -> (estimator, param_grid). Grid keys use the pipeline prefix 'clf__'."""
    m = {
        "Logistic Regression": (LogisticRegression(max_iter=1000),
                                {"clf__C": [0.1, 1, 10]}),
        "Naive Bayes": (GaussianNB(), {"clf__var_smoothing": [1e-9, 1e-7, 1e-5]}),
        "SVM": (SVC(probability=True, random_state=SEED),
                {"clf__C": [0.5, 1, 5], "clf__kernel": ["rbf", "linear"]}),
        "KNN": (KNeighborsClassifier(),
                {"clf__n_neighbors": [5, 11, 21], "clf__weights": ["uniform", "distance"]}),
        "Decision Tree": (DecisionTreeClassifier(random_state=SEED),
                          {"clf__max_depth": [3, 5, 8, None], "clf__min_samples_leaf": [1, 10]}),
        "Random Forest": (RandomForestClassifier(random_state=SEED, n_jobs=-1),
                          {"clf__n_estimators": [100, 250], "clf__max_depth": [8, None]}),
        "AdaBoost": (AdaBoostClassifier(random_state=SEED),
                     {"clf__n_estimators": [50, 150], "clf__learning_rate": [0.5, 1.0]}),
    }
    try:
        from xgboost import XGBClassifier
        m["XGBoost"] = (XGBClassifier(eval_metric="logloss", random_state=SEED, n_jobs=1),
                        {"clf__n_estimators": [100, 250], "clf__max_depth": [3, 5],
                         "clf__learning_rate": [0.05, 0.15]})
    except ImportError:   # keeps the project runnable without xgboost
        m["Gradient Boosting"] = (GradientBoostingClassifier(random_state=SEED),
                                  {"clf__n_estimators": [100, 250], "clf__max_depth": [2, 3],
                                   "clf__learning_rate": [0.05, 0.15]})
    return m


def pipe(est):
    return Pipeline([("prep", data_prep.make_preprocessor()), ("clf", est)])


def scores(model, X, y):
    pred, proba = model.predict(X), model.predict_proba(X)[:, 1]
    return {"accuracy": accuracy_score(y, pred), "precision": precision_score(y, pred),
            "recall": recall_score(y, pred), "f1": f1_score(y, pred),
            "roc_auc": roc_auc_score(y, proba)}


def main():
    for d in (DATA, MODELS, RESULTS):
        d.mkdir(exist_ok=True)
    raw_path = DATA / "raw_simulated.csv"
    raw = pd.read_csv(raw_path) if raw_path.exists() else simulate.run()

    df, report = data_prep.clean(raw)
    json.dump(report, open(RESULTS / "cleaning_report.json", "w"), indent=2)
    df.to_csv(DATA / "cleaned.csv", index=False)

    X, y = df[data_prep.ALL_FEATURES], df[data_prep.TARGET]
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, stratify=y, random_state=SEED)
    pd.concat([X_tr, y_tr], axis=1).to_csv(DATA / "train.csv", index=False)
    pd.concat([X_te, y_te], axis=1).to_csv(DATA / "test.csv", index=False)
    print(f"Split 80/20 (stratified): train={len(X_tr)}  test={len(X_te)}")

    rows, best_params, preds, imp_rows = [], {}, {"y_true": y_te.to_numpy()}, []
    tuned_models = {}
    for name, (est, grid) in build_models().items():
        t0 = time.time()
        base = pipe(clone(est)).fit(X_tr, y_tr)
        rows.append({"model": name, "stage": "baseline", **scores(base, X_te, y_te),
                     "cv_f1": np.nan, "fit_seconds": round(time.time() - t0, 2)})

        t0 = time.time()
        gs = GridSearchCV(pipe(clone(est)), grid, cv=3, scoring="f1", n_jobs=-1).fit(X_tr, y_tr)
        best = gs.best_estimator_
        rows.append({"model": name, "stage": "tuned", **scores(best, X_te, y_te),
                     "cv_f1": gs.best_score_, "fit_seconds": round(time.time() - t0, 2)})
        best_params[name] = {k: (v.item() if hasattr(v, "item") else v)
                             for k, v in gs.best_params_.items()}   # keep int/str/None types
        preds[f"proba_{name}"] = best.predict_proba(X_te)[:, 1]
        joblib.dump(best, MODELS / f"{slug(name)}.joblib")
        tuned_models[name] = best

        pi = permutation_importance(best, X_te, y_te, scoring="roc_auc", n_repeats=3,
                                    random_state=SEED, n_jobs=-1)
        for f, mu, sd in zip(X_te.columns, pi.importances_mean, pi.importances_std):
            imp_rows.append({"model": name, "feature": f, "importance": mu, "std": sd})
        last = rows[-1]
        print(f"{name:20s} tuned  acc={last['accuracy']:.3f}  f1={last['f1']:.3f}  "
              f"auc={last['roc_auc']:.3f}  {best_params[name]}")

    pd.DataFrame(rows).to_csv(RESULTS / "metrics.csv", index=False)
    json.dump(best_params, open(RESULTS / "best_params.json", "w"), indent=2)
    pd.DataFrame(preds).to_csv(RESULTS / "test_predictions.csv", index=False)
    pd.DataFrame(imp_rows).to_csv(RESULTS / "perm_importance.csv", index=False)

    dt = tuned_models["Decision Tree"]
    names = dt.named_steps["prep"].get_feature_names_out()
    fig, ax = plt.subplots(figsize=(16, 7))
    plot_tree(dt.named_steps["clf"], max_depth=3, feature_names=names,
              class_names=["Hit", "Survived"], filled=True, fontsize=7, ax=ax)
    fig.savefig(RESULTS / "decision_tree.png", dpi=130, bbox_inches="tight")
    print("All artefacts saved in data/, models/, results/")


if __name__ == "__main__":
    main()
