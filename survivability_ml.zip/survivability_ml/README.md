# Aircraft Survivability: ML Model Comparison (Mini Project)

Software-only study. A Monte Carlo simulator creates labelled outcomes (survived / hit) for
notional aircraft engagements under four protection modes (none, decoy, manoeuvre, hybrid).
Eight ML models are trained, tuned and compared; a Streamlit app shows graphs, model
explainers and an animated map simulation.

**Limitations (state these in the report/viva):** no public dataset of real engagement outcomes
exists, so labels come from assumed probabilities in `simulate.py`; the hybrid unit is a generic
black box (detect p, neutralise q). Results describe the model, not any real system.

## Run locally (Windows / VS Code)
    python -m venv venv
    venv\Scripts\activate
    pip install -r requirements.txt
    python simulate.py        # optional: app generates data on first run if missing
    python train.py
    streamlit run app.py

## Use real aircraft kinematics (optional)
Download ADS-B data (e.g. OpenSky Network), then:
    python simulate.py --real-csv your_file.csv --speed-unit m/s --alt-unit m
    python train.py

## Files
simulate.py (data generator) | data_prep.py (cleaning + pipeline) | train.py (models, tuning, metrics)
app.py (Streamlit UI) | data/ models/ results/ (generated artefacts)

## Deploy (cross-platform access)
Push to GitHub, then create an app on Streamlit Community Cloud pointing at `app.py`.
Commit data/, models/ and results/ (small) or let the app rebuild them on first run.
